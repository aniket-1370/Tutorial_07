# CS543 Tutorial 7 — Campus Library

**Course:** CS543  
**Group ID:** 02

## Team Members

| S. No. | Name | Roll Number |
|---|---|---|
| 1 | AMAN KUMAR | 20251651017 |
| 2 | SHRIKANTA NAYAK | 20251651090 |
| 3 | ADITYA VERMA | 20251651009 |
| 4 | PRATIK SINHA | 20251651071 |

## Project Overview

Campus Library is a small web application demonstrating how a browser frontend communicates with a GraphQL API connected to a MySQL database.

The project has three layers:

1. **Frontend:** HTML and CSS
2. **API:** Node.js and Apollo GraphQL
3. **Database:** MySQL

Users can view authors and their books, run GraphQL queries, and add new books through the frontend.

## Requirements

- Node.js 18+
- MySQL Server 8+
- Visual Studio Code
- Live Server extension for VS Code

## 1. Create the Database

Open PowerShell in the project folder and connect to MySQL:

```bash
mysql -u root -p
```

Enter your MySQL root password.

At the MySQL prompt, execute `schema.sql` using its full path. For example:

```sql
SOURCE C:/Users/YOUR_USER/Downloads/CS543_Tutorial7_Campus_Library/schema.sql;
```

Replace `YOUR_USER` and the folder path with your actual Windows username and project location.

Verify the database and tables:

```sql
USE gqldemo;

SELECT * FROM authors;

SELECT * FROM books;
```

The database contains the authors and books used by the Campus Library application.

## 2. Configure the MySQL Password

Open `db.js` in VS Code.

Replace `YOUR_MYSQL_PASSWORD` with your actual MySQL root password.

Save the file before starting the application.

**Security note:** Do not share your database password or include your real password in the submitted project ZIP.

## 3. Install Dependencies

Open a terminal in the project root directory and run:

```bash
npm install
```

This installs the dependencies listed in `package.json`.

## 4. Start the GraphQL API

Run:

```bash
npm start
```

The expected terminal output includes:

```text
MySQL connection successful.
GraphQL API ready at http://localhost:4000/
```

Keep this terminal running while testing the application.

## 5. Test the GraphQL Query

Open the following URL in your browser:

[http://localhost:4000/](http://localhost:4000/)

Use Apollo Sandbox to execute this query:

```graphql
query {
  authors {
    name
    country
    books {
      title
      year
    }
  }
}
```

The query retrieves author information and the books associated with each author.

Check that the returned data includes author names, countries, book titles, and publication years.

## 6. Test the Add Book Mutation

In Apollo Sandbox, execute the following mutation:

```graphql
mutation {
  addBook(
    title: "GraphQL for Beginners"
    year: 2025
    authorId: 1
  ) {
    id
    title
    year
  }
}
```

This example adds a book associated with the author whose ID is `1`.

The author ID must exist in the database. If necessary, check the available IDs using:

```sql
USE gqldemo;

SELECT * FROM authors;
```

The mutation should return the newly created book's ID, title, and year.

## 7. Run the Frontend

1. Open the project in VS Code.
2. Open `public/index.html`.
3. Right-click the file and select **Open with Live Server**.
4. The frontend usually opens at:

   [http://127.0.0.1:5500](http://127.0.0.1:5500)

5. View the available books and use the **Add a book** form to insert a new book.

Ensure the GraphQL API is still running on port `4000`.

## 8. Verify the Inserted Data in MySQL

Open MySQL and run:

```sql
USE gqldemo;

SELECT title, year, author_id
FROM books;
```

The query displays book titles, publication years, and their associated author IDs.

Verify that the book added through the frontend or GraphQL mutation appears in the database.

## 9. Project Structure

```text
CS543_Tutorial7/
├── server.js
├── db.js
├── package.json
├── schema.sql
├── README.md
├── SUBMISSION_CHECKLIST.md
├── screenshots/
│   ├── 01_mysql_books_table.png
│   ├── 02_graphql_query_success.png
│   ├── 03_graphql_addbook_mutation.png
│   ├── 04_campus_library_frontend.png
│   └── 05_mysql_join_verification.png
└── public/
    ├── index.html
    └── style.css
```

The `screenshots` folder should contain your actual screenshots. The structure above assumes you create that folder and place the images inside it.

## 10. Troubleshooting

| Problem | Possible Solution |
|---|---|
| `ECONNREFUSED` | Ensure the MySQL Server is running and the database connection settings are correct. |
| `Access denied` | Check the MySQL username and password in `db.js`. |
| `Unknown database` | Import `schema.sql` and verify that the `gqldemo` database exists. |
| GraphQL API does not start | Check the terminal error and confirm that the dependencies are installed. |
| Port 4000 is already in use | Stop the other process using the port or configure an available port consistently. |
| Frontend cannot connect | Ensure the GraphQL API is running on port 4000 and check the frontend's API URL. |
| Book is not added | Check the browser console, GraphQL response, and whether the selected author ID exists. |

## Conclusion

The Campus Library project demonstrates the integration of an HTML/CSS frontend, a Node.js Apollo GraphQL API, and a MySQL database.

It covers database setup, GraphQL queries, mutations, frontend integration, and database verification as part of CS543 Tutorial 7.

