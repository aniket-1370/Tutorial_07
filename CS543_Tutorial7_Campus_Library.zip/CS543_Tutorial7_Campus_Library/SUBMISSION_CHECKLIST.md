# CS543 Tutorial 7 — Submission Checklist

**Course:** CS543  
**Group ID:** 02  
**Project:** Campus Library — GraphQL and MySQL

## 1. Project Files

- [ ] `server.js`
- [ ] `db.js`
- [ ] `package.json`
- [ ] `schema.sql`
- [ ] `README.md`
- [ ] `SUBMISSION_CHECKLIST.md`
- [ ] `public/index.html`
- [ ] `public/style.css`
- [ ] `screenshots/` folder containing the actual screenshots

## 2. Database Verification

- [ ] MySQL Server is running.
- [ ] Database `gqldemo` has been created.
- [ ] `authors` table contains the expected data.
- [ ] `books` table contains the expected data.
- [ ] Book records are associated with valid author IDs.

## 3. GraphQL API Verification

- [ ] Dependencies installed using `npm install`.
- [ ] API starts successfully using `npm start`.
- [ ] MySQL connection is successful.
- [ ] GraphQL API is accessible at `http://localhost:4000/`.
- [ ] Authors and books query returns the expected data.
- [ ] `addBook` mutation successfully adds a book.

## 4. Frontend Verification

- [ ] Frontend opens using VS Code Live Server.
- [ ] Authors and books are displayed correctly.
- [ ] Add a book form works.
- [ ] Newly added books appear in MySQL.

## 5. Screenshots

- [ ] `01_mysql_books_table.png`
- [ ] `02_graphql_query_success.png`
- [ ] `03_graphql_addbook_mutation.png`
- [ ] `04_campus_library_frontend.png`
- [ ] `05_mysql_join_verification.png`

Make sure all screenshots are actual captures of your working application.

## 6. Final ZIP Verification

- [ ] All required project files are included.
- [ ] The `public` and `screenshots` folders are included.
- [ ] `node_modules` is excluded; dependencies can be reinstalled using `npm install`.
- [ ] No real database passwords or other secrets are included.
- [ ] The ZIP opens successfully and contains the project folder.

**Suggested ZIP filename:** `CS543_Tutorial7_Group02.zip`

