const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Aman@8081',
    database: 'gqldemo',
    waitForConnections: true,
    connectionLimit: 10, queueLimit: 0
});

module.exports = pool;
